import { type NextRequest, NextResponse } from "next/server"
import { db } from "@/db"
import { communityTips } from "@/db/schema"
import { eq } from "drizzle-orm"

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const tip = await db.select().from(communityTips).where(eq(communityTips.id, params.id))

    if (!tip.length) {
      return NextResponse.json({ error: "Tip not found" }, { status: 404 })
    }

    await db
      .update(communityTips)
      .set({
        upvotes: tip[0]?.upvotes ? tip[0]?.upvotes + 1 : 1,
      })
      .where(eq(communityTips.id, params.id))

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Upvote error:", error)
    return NextResponse.json({ error: "Failed to upvote tip" }, { status: 500 })
  }
}
