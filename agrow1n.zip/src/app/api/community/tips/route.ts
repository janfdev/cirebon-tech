import { type NextRequest, NextResponse } from "next/server"
import { db } from "@/db"
import { communityTips, user } from "@/db/schema"
import { eq } from "drizzle-orm"

export async function GET(req: NextRequest) {
  try {
    const tips = await db
      .select()
      .from(communityTips)
      .where(eq(communityTips.isPublished, true))
      .leftJoin(user, eq(communityTips.userId, user.id))

    const formatted = tips.map(({ community_tips, user: u }) => ({
      id: community_tips.id,
      title: community_tips.title,
      content: community_tips.content,
      cropName: community_tips.cropName,
      location: community_tips.location,
      upvotes: community_tips.upvotes,
      createdAt: community_tips.createdAt,
      user: {
        name: u?.name,
        farmName: u?.name,
      },
    }))

    return NextResponse.json(formatted)
  } catch (error) {
    console.error("Tips fetch error:", error)
    return NextResponse.json({ error: "Failed to fetch tips" }, { status: 500 })
  }
}
