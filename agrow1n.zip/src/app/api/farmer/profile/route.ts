import { type NextRequest, NextResponse } from "next/server"
import { db } from "@/db"
import { farmerProfile, user } from "@/db/schema"
import { eq } from "drizzle-orm"
import { auth } from "@/lib/auth"

export async function GET(req: NextRequest) {
  try {
    const session = await auth.api.getSession({
      headers: req.headers,
    })

    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const profile = await db
      .select()
      .from(farmerProfile)
      .where(eq(farmerProfile.userId, session.user.id))
      .leftJoin(user, eq(farmerProfile.userId, user.id))

    if (profile.length === 0) {
      // Create default profile if not exists
      const profileId = `profile-${Date.now()}`
      await db.insert(farmerProfile).values({
        id: profileId,
        userId: session.user.id,
      })

      const newProfile = await db.select().from(farmerProfile).where(eq(farmerProfile.userId, session.user.id))

      return NextResponse.json(newProfile[0])
    }

    return NextResponse.json(profile[0])
  } catch (error) {
    console.error("Profile fetch error:", error)
    return NextResponse.json({ error: "Failed to fetch profile" }, { status: 500 })
  }
}

export async function PUT(req: NextRequest) {
  try {
    const session = await auth.api.getSession({
      headers: req.headers,
    })

    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await req.json()

    await db
      .update(farmerProfile)
      .set({
        ...body,
        updatedAt: new Date(),
      })
      .where(eq(farmerProfile.userId, session.user.id))

    const updated = await db.select().from(farmerProfile).where(eq(farmerProfile.userId, session.user.id))

    return NextResponse.json(updated[0])
  } catch (error) {
    console.error("Profile update error:", error)
    return NextResponse.json({ error: "Failed to update profile" }, { status: 500 })
  }
}
