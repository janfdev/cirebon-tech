import { type NextRequest, NextResponse } from "next/server"
import { db } from "@/db"
import { reminders, plantingHistory } from "@/db/schema"
import { eq, and, lte } from "drizzle-orm"
import { auth } from "@/lib/auth"

export async function GET(req: NextRequest) {
  try {
    const session = await auth.api.getSession({
      headers: req.headers,
    })

    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Get upcoming reminders (next 7 days)
    const sevenDaysFromNow = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)

    const upcomingReminders = await db
      .select()
      .from(reminders)
      .where(
        and(
          eq(reminders.userId, session.user.id),
          eq(reminders.isCompleted, false),
          lte(reminders.scheduledDate, sevenDaysFromNow),
        ),
      )

    // Also generate automatic reminders based on planting history
    const activePlants = await db
      .select()
      .from(plantingHistory)
      .where(and(eq(plantingHistory.userId, session.user.id), eq(plantingHistory.isCompleted, false)))

    // Add watering reminders for active plants (every 3 days)
    const autoReminders: any[] = []
    activePlants.forEach((plant) => {
      const lastReminder = upcomingReminders.find(
        (r) => r.plantingHistoryId === plant.id && r.reminderType === "watering",
      )

      if (!lastReminder || new Date(lastReminder.scheduledDate).getTime() < Date.now()) {
        autoReminders.push({
          id: `auto-reminder-${plant.id}-watering`,
          reminderType: "watering",
          message: `Siram tanaman ${plant.cropName} Anda`,
          scheduledDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000),
          cropName: plant.cropName,
          isCompleted: false,
          plantingHistoryId: plant.id,
        })
      }
    })

    return NextResponse.json([...upcomingReminders, ...autoReminders])
  } catch (error) {
    console.error("Reminders fetch error:", error)
    return NextResponse.json({ error: "Failed to fetch reminders" }, { status: 500 })
  }
}
